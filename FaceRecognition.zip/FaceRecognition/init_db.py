import sqlite3
import os

# Delete existing database file if it exists
if os.path.exists('face_recognition.db'):
    try:
        os.remove('face_recognition.db')
        print("Deleted existing database file")
    except PermissionError:
        print("Could not delete database file - it may be in use by another process")
        print("Please close all applications and try again")
        exit(1)

# Create a new database connection
conn = sqlite3.connect('face_recognition.db')
cursor = conn.cursor()
print("Connected to database")

# Create students table
cursor.execute('''
CREATE TABLE students (
    Department TEXT,
    Course TEXT,
    Year TEXT,
    Semester TEXT,
    Student_ID TEXT PRIMARY KEY,
    Name TEXT,
    Section TEXT,
    RollNo TEXT,
    Gender TEXT,
    Address TEXT,
    Phone TEXT,
    DOB TEXT,
    Photo TEXT
)
''')
print("Created students table")

# Insert a sample student
cursor.execute('''
INSERT INTO students VALUES (
    'CSE', 'DSA', '3rd', '5th', '1', 'John Doe', 'A', 
    '123456', 'Male', '123 Main St', '555-1234', '1999-01-01', 'Yes'
)
''')
print("Added sample student")

# Commit and close
conn.commit()
conn.close()
print("Database initialized successfully") 