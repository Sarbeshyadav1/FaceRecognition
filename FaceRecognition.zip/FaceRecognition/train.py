from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
import numpy as np
import cv2
import os
import re

class Train:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("Face Recognition Based Standard Attendance System")

        title_lbl = Label(self.root, text="TRAIN DATA SET", font=(
            "times new roman", 25, "bold"), bg="white", fg="red")
        title_lbl.place(x=0, y=0, width=1300, height=45)

        img_top = Image.open("images/facerecognition.png")
        img_top = img_top.resize((1300,275))
        self.photoimage_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimage_top)
        f_lbl.place(x=0, y=45, width=1300, height=275)

        b1_1 = Button(self.root, text='Train data', command=self.train_classifier, cursor="hand2", font=(
            "times new roman", 25, "bold"), bg="darkblue", fg="white")
        b1_1.place(x=0, y=320, width=1300, height=60)

        img_bottom = Image.open("images/facial-recognition.jpg")
        img_bottom = img_bottom.resize((1300,300))
        self.photoimage_bottom = ImageTk.PhotoImage(img_bottom)

        f_lbl = Label(self.root, image=self.photoimage_bottom)
        f_lbl.place(x=0, y=380, width=1300, height=300)

    def extract_id_from_filename(self, filename):
        """Extract student ID from filename supporting different formats:
           - user.ID.sequence.jpg (where ID can be numeric or alphanumeric)
           - user.alphanumericID.sequence.jpg
        """
        try:
            # Get the base filename without path and extension
            base_name = os.path.basename(filename)
            parts = base_name.split('.')
            
            # If the filename follows user.ID.sequence.jpg format
            if len(parts) >= 3 and parts[0].lower() == 'user':
                # Return the ID part as string (works for both numeric and alphanumeric IDs)
                return parts[1]
            else:
                raise ValueError(f"Filename {filename} doesn't follow expected format (user.ID.jpg)")
        except Exception as e:
            raise ValueError(f"Error extracting ID from {filename}: {str(e)}")

    def train_classifier(self):
        data_dir = "data"
        
        # Create data directory if it doesn't exist
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
            messagebox.showinfo("Information", "Data directory created. Please add student images to the 'data' folder before training.")
            return
            
        # Check if there are any files in the data directory
        if len(os.listdir(data_dir)) == 0:
            messagebox.showwarning("Warning", "No images found in the data directory. Please add student images first.")
            return
            
        try:
            # Make sure haarcascade file exists
            if not os.path.isfile("haarcascade_frontalface_default.xml"):
                messagebox.showerror("Error", "Haar cascade file missing! Please download it first.")
                return
                
            path = [os.path.join(data_dir, file) for file in os.listdir(data_dir) if file.lower().endswith(('.png', '.jpg', '.jpeg'))]

            faces = []
            ids = []
            id_mapping = {}  # Dictionary to map alphanumeric IDs to numeric IDs for training
            next_numeric_id = 1

            for image in path:
                try:
                    img = Image.open(image).convert('L')  # L to convert to Grey scale image
                    imageNp = np.array(img, 'uint8')
                    
                    # Extract the student ID from the filename
                    try:
                        # Get the ID as string
                        id_str = self.extract_id_from_filename(image)
                        
                        # If this ID isn't in our mapping yet, add it
                        if id_str not in id_mapping:
                            id_mapping[id_str] = next_numeric_id
                            next_numeric_id += 1
                            
                        # Use the numeric mapped ID for training
                        id_num = id_mapping[id_str]
                        
                        faces.append(imageNp)
                        ids.append(id_num)
                        cv2.imshow("Training", imageNp)
                        cv2.waitKey(1)==13  # window closes on pressing enter
                    except Exception as e:
                        messagebox.showwarning("Warning", f"File {image} does not follow the required naming format (user.ID.jpg). Skipping this file. Error: {str(e)}")
                        continue
                except Exception as e:
                    messagebox.showwarning("Warning", f"Error processing image {image}: {str(e)}")
                    continue
                    
            if len(faces) == 0:
                messagebox.showerror("Error", "No valid face images found for training. Please check your images.")
                cv2.destroyAllWindows()
                return
                
            ids = np.array(ids)

            # Train classifier and save
            clf = cv2.face.LBPHFaceRecognizer_create()
            clf.train(faces, ids)
            clf.write("classfier.xml")
            
            # Save the ID mapping for later use
            import json
            with open("id_mapping.json", "w") as f:
                json.dump(id_mapping, f)
                
            cv2.destroyAllWindows()
            messagebox.showinfo("Success", f"Training completed successfully with {len(faces)} images!")
        except Exception as e:
            cv2.destroyAllWindows()
            messagebox.showerror("Error", f"Training failed: {str(e)}")


if __name__ == "__main__": 
    root = Tk()
    obj = Train(root)
    root.mainloop()