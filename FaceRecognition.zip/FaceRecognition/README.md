# Face Recognition Attendance System

## Overview
This is an automated attendance management system that uses facial recognition technology to mark student attendance. The system captures live video feed, recognizes faces, identifies students, and automatically records their attendance in a database and CSV file.

## Key Features
- **Facial Recognition**: Automatically detects and recognizes student faces
- **Automated Attendance**: Marks attendance in real-time when a face is recognized
- **User-Friendly UI**: Graphical interface for easy navigation and operation
- **Attendance Viewing**: Dedicated interface to view and manage attendance records
- **Secure Database**: Student information and attendance records stored securely

## How to Use
1. **Launch the Application**: Run `python main.py`
2. **Face Recognition**: Click "Face Recognition" to start the camera
3. **Mark Attendance**: When your face is recognized, attendance is automatically marked
4. **View Attendance**: Click "View Attendance" to see all attendance records
5. **Exit**: Press 'q' to close the face recognition window

## Installation
1. Clone the repository
2. Install required packages: `pip install -r requirements.txt`
3. Run the application: `python main.py`

## System Requirements
- Python 3.6 or higher
- Webcam or camera device
- Required libraries: OpenCV, NumPy, PIL, tkinter

## Data Privacy
The system only stores essential student information and attendance records. All data is kept locally and is not shared with external services. 