import os
import cv2
import numpy as np
from time import strftime
from datetime import datetime
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
import sqlite3
import json

class Face_Recognition:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("Face Recognition Based Standard Attendance System")

        # Create SQLite database if it doesn't exist
        self.create_db()

        title_lbl = Label(self.root, text="FACE RECOGNITION", font=(
            "times new roman", 25, "bold"), bg="white", fg="blue")
        title_lbl.place(x=0, y=0, width=1300, height=45)

        # left image
        img_top = Image.open("images/faceRecognize.png")
        img_top = img_top.resize((650,650))
        self.photoimage_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimage_top)
        f_lbl.place(x=0, y=45, width=650, height=650)

        # right image
        img_bottom = Image.open("images/facial_recognition.jpg")
        img_bottom = img_bottom.resize((650,650))
        self.photoimage_bottom = ImageTk.PhotoImage(img_bottom)

        f_lbl = Label(self.root, image=self.photoimage_bottom)
        f_lbl.place(x=650, y=45, width=650, height=650)

        b1_1 = Button(self.root, text='Face Recognition', cursor="hand2", command=self.face_recognize, font=(
            "times new roman", 15, "bold"), bg="darkgreen", fg="white")
        b1_1.place(x=230, y=570, width=180, height=40)
        
        # Add view attendance button
        b1_2 = Button(self.root, text='View Attendance', cursor="hand2", command=self.view_attendance, font=(
            "times new roman", 15, "bold"), bg="darkblue", fg="white")
        b1_2.place(x=450, y=570, width=180, height=40)

    def create_db(self):
        try:
            # Use a timeout to avoid database locked issues
            conn = sqlite3.connect('face_recognition.db', timeout=10)
            cursor = conn.cursor()
            
            # Create students table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS students (
                Department TEXT,
                Course TEXT,
                Year TEXT,
                Semester TEXT,
                Student_ID TEXT PRIMARY KEY,
                Name TEXT,
                Section TEXT,
                RollNo TEXT,
                Gender TEXT,
                Address TEXT,
                Phone TEXT,
                DOB TEXT,
                Photo TEXT
            )
            ''')
            
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to initialize database: {str(e)}")

    # attendance
    def mark_attendance(self, i, r, n, d):
        try:
            # Create file with headers if it doesn't exist
            if not os.path.exists('attendance.csv'):
                with open('attendance.csv', 'w', newline='') as f:
                    f.write("Student_ID,RollNo.,Name,Department,Time,Date,Status\n")
            
            # Read existing entries to check for duplicates
            name_List = []
            dateList = []
            try:
                with open('attendance.csv', "r", newline='') as f:
                    myData = f.readlines()
                    for line in myData:
                        entry = line.split(",")
                        if len(entry) > 0:
                            name_List.append(entry[0])
                        if len(entry) > 5:
                            dateList.append(entry[5])
            except:
                # If file reading fails, create a new file
                with open('attendance.csv', 'w', newline='') as f:
                    f.write("Student_ID,RollNo.,Name,Department,Time,Date,Status\n")
                
            now = datetime.now()
            dt = now.strftime("%d/%m/%Y")
            dtString = now.strftime("%H:%M:%S")
            
            # Check if this student is already marked for today
            already_marked = False
            for idx, name in enumerate(name_List):
                if str(i) == name and idx < len(dateList) and dt in dateList[idx]:
                    already_marked = True
                    break
                    
            if not already_marked:
                with open('attendance.csv', "a", newline='') as f:
                    f.write(f"{i},{r},{n},{d},{dtString},{dt},Present\n")
                return True  # Indicate that attendance was marked
            return False  # Indicate that attendance was already marked
        except Exception as e:
            messagebox.showerror("Error", f"Error writing to attendance file: {str(e)}")
            return False


    # face recognition
    def face_recognize(self):
        # Check if classifier file exists
        if not os.path.isfile("classfier.xml"):
            messagebox.showerror("Error", "Classifier file not found! Please train the model first.")
            return
            
        # Load the ID mapping if it exists
        id_mapping = {}
        reverse_mapping = {}
        
        if os.path.exists("id_mapping.json"):
            try:
                with open("id_mapping.json", "r") as f:
                    id_mapping = json.load(f)
                    
                # Create reverse mapping (numeric to string ID)
                for str_id, num_id in id_mapping.items():
                    reverse_mapping[str(num_id)] = str_id
            except Exception as e:
                messagebox.showwarning("Warning", f"Could not load ID mapping: {str(e)}")
        
        # To track recognized students
        recognized_students = set()
            
        def draw_boundary(img, classifier, scaleFactor, minNeighbours, color, text, clf):
            gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            features = classifier.detectMultiScale(gray_img, scaleFactor, minNeighbours)

            coord = []
            attendance_marked = False

            for (x,y,w,h) in features:
                cv2.rectangle(img, (x,y), (x+w, y+h), (0,255,0), 2)
                id, predict = clf.predict(gray_img[y:y+h, x:x+w])
                confidence = int((100*(1-predict/300)))

                try:
                    # Convert numeric ID back to string ID if mapping exists
                    real_id = reverse_mapping.get(str(id), str(id))
                    
                    # Use a timeout to avoid database locked issues
                    conn = sqlite3.connect('face_recognition.db', timeout=10)
                    cursor = conn.cursor()

                    cursor.execute("SELECT Student_ID FROM students WHERE Student_ID=?", (real_id,))
                    i = cursor.fetchone()
                    
                    if i:
                        i = i[0]
                        
                        cursor.execute("SELECT RollNo FROM students WHERE Student_ID=?", (real_id,))
                        r = cursor.fetchone()
                        r = r[0]

                        cursor.execute("SELECT Name FROM students WHERE Student_ID=?", (real_id,))
                        n = cursor.fetchone()
                        n = n[0]

                        cursor.execute("SELECT Department FROM students WHERE Student_ID=?", (real_id,))
                        d = cursor.fetchone()
                        d = d[0]

                        if confidence > 77:
                            cv2.putText(img, f"Student Id:{i}", (x, y-75), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                            cv2.putText(img, f"Roll no:{r}", (x, y-55), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                            cv2.putText(img, f"Name:{n}", (x, y-25), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                            cv2.putText(img, f"Department:{d}", (x, y-5), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                            
                            # Mark attendance if this student was not already recognized
                            if i not in recognized_students:
                                attendance_marked = self.mark_attendance(i,r,n,d)
                                recognized_students.add(i)
                                
                                # Show attendance marked message on the image
                                if attendance_marked:
                                    cv2.putText(img, "Attendance Marked!", (x, y+h+20), cv2.FONT_HERSHEY_COMPLEX, 0.7, (0, 255, 0), 2)
                        
                        else:
                            cv2.rectangle(img, (x,y), (x+w, y+h), (255,0,0), 2)
                            cv2.putText(img, "Unknown face", (x, y-10), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                    else:
                        cv2.rectangle(img, (x,y), (x+w, y+h), (255,0,0), 2)
                        cv2.putText(img, "Unknown face", (x, y-10), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                    
                    # Close connection properly
                    conn.commit()
                    conn.close()
                    
                except Exception as e:
                    # Handle database connection error
                    print(f"Database connection error: {str(e)}")
                    cv2.rectangle(img, (x,y), (x+w, y+h), (255,0,0), 2)
                    if confidence > 77:
                        cv2.putText(img, f"ID: {id}", (x, y-25), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                        cv2.putText(img, "DB Error", (x, y-5), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)
                    else:
                        cv2.putText(img, "Unknown face", (x, y-10), cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 255, 0), 2)

                coord = [x,y,w,h]
            return coord
        
        def recognize(img, clf, faceCascade):
            coord = draw_boundary(img, faceCascade, 1.1, 10, (255,25,255), "Face", clf)
            return img
        
        try:
            # Make sure required files exist
            if not os.path.isfile("haarcascade_frontalface_default.xml"):
                messagebox.showerror("Error", "Missing haarcascade_frontalface_default.xml file. Please download it first.")
                return
                
            faceCascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
            clf = cv2.face.LBPHFaceRecognizer_create()
            clf.read("classfier.xml")
            video_cap = cv2.VideoCapture(0)

            if not video_cap.isOpened():
                messagebox.showerror("Error", "Could not open camera. Please check your camera connection.")
                return

            # Add exit instructions to the window
            exit_button_pressed = False
            
            while True:
                ret, img = video_cap.read()
                if not ret:
                    messagebox.showerror("Error", "Could not get frame from camera.")
                    break
                
                # Add instructions to close the window
                cv2.putText(img, "Press 'q' to exit", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                
                # Process the frame for face recognition
                img = recognize(img, clf, faceCascade)
                
                # Display the frame
                cv2.imshow("Face Recognition", img)
                
                # Check for key press to exit
                key = cv2.waitKey(1)
                if key == ord('q') or key == 27:  # 'q' or ESC key
                    exit_button_pressed = True
                    break
            
            video_cap.release()
            cv2.destroyAllWindows()
            
            # Show summary of attendance after closing the window
            if exit_button_pressed and recognized_students:
                messagebox.showinfo("Attendance Summary", f"Attendance marked for {len(recognized_students)} student(s)")
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            # Make sure to release resources even if an error occurs
            try:
                video_cap.release()
                cv2.destroyAllWindows()
            except:
                pass

    # Function to view attendance
    def view_attendance(self):
        try:
            if not os.path.exists('attendance.csv'):
                messagebox.showinfo("Information", "No attendance records found.")
                return
                
            # Create a new window to display attendance
            attendance_window = Toplevel(self.root)
            attendance_window.title("Attendance Records")
            attendance_window.geometry("800x600+100+100")
            
            # Add scrollable text widget
            scroll_y = Scrollbar(attendance_window, orient=VERTICAL)
            attendance_text = Text(attendance_window, yscrollcommand=scroll_y.set, font=("times new roman", 12))
            scroll_y.pack(side=RIGHT, fill=Y)
            scroll_y.config(command=attendance_text.yview)
            attendance_text.pack(fill=BOTH, expand=1)
            
            # Read and display attendance data
            try:
                with open('attendance.csv', 'r') as f:
                    attendance_data = f.readlines()
                    
                if len(attendance_data) <= 1:  # Only header exists
                    attendance_text.insert(END, "No attendance records found.\n")
                else:
                    # Format each line to be more readable
                    for line in attendance_data:
                        entries = line.strip().split(',')
                        if len(entries) >= 7:  # Ensure we have all fields
                            formatted_line = f"ID: {entries[0]}, Roll: {entries[1]}, Name: {entries[2]}, Dept: {entries[3]}, Time: {entries[4]}, Date: {entries[5]}, Status: {entries[6]}\n"
                            attendance_text.insert(END, formatted_line)
                        else:
                            attendance_text.insert(END, line)  # Display as is if format is unexpected
            except Exception as e:
                attendance_text.insert(END, f"Error reading attendance file: {str(e)}\n")
                
            # Button to close the window
            close_btn = Button(attendance_window, text="Close", command=attendance_window.destroy, 
                              font=("times new roman", 12, "bold"), bg="red", fg="white")
            close_btn.pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred while viewing attendance: {str(e)}")


if __name__ == "__main__": 
    root = Tk()
    obj = Face_Recognition(root)
    root.mainloop()