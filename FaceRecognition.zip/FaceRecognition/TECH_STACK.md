# Technical Documentation - Face Recognition Attendance System

## Tech Stack

### Programming Language
- **Python**: The entire project is built using Python 3.x, chosen for its simplicity, readability, and extensive libraries for computer vision and GUI development.

### Libraries and Frameworks
- **OpenCV (cv2)**: Used for face detection, image processing, and machine learning algorithms
- **NumPy**: Handles numerical operations and arrays for image data processing
- **PIL (Pillow)**: Used for image manipulation in the UI
- **tkinter**: Provides the graphical user interface
- **SQLite3**: Lightweight database for storing student information
- **datetime**: Manages date and time operations for attendance records

### Face Recognition Technology
- **Haar Cascade Classifier**: For face detection
- **LBPH (Local Binary Patterns Histograms) Face Recognizer**: For face recognition
- **XML Classifier**: Trained model for identifying faces

## Code Structure and Functionality

### Main Components
1. **main.py**: Entry point of the application, initializes the system

2. **face_recognizer.py**: Core component handling face recognition and attendance
   - `Face_Recognition` class: Main class containing all functionality
   - `create_db()`: Initializes the SQLite database
   - `mark_attendance()`: Records student attendance in CSV file
   - `face_recognize()`: Implements the face detection and recognition logic
   - `view_attendance()`: Displays attendance records in a readable format

3. **attendance.csv**: Stores attendance records in CSV format with fields:
   - Student_ID, RollNo., Name, Department, Time, Date, Status

4. **face_recognition.db**: SQLite database storing student information:
   - Student details (ID, name, department, etc.)
   - Links to trained face data

5. **classifier.xml**: Trained face recognition model

### Workflow
1. **Initialization**:
   - System loads the UI and initializes database connections
   - Checks for required files (classifier.xml, haarcascade_frontalface_default.xml)

2. **Student Registration** (done separately):
   - Student information is stored in the database
   - Face samples are collected and used to train the recognizer

3. **Face Recognition Process**:
   - Camera captures video feed
   - Haar Cascade detects faces in the frame
   - LBPH recognizer identifies the detected face
   - System retrieves student information from database
   - Confidence score determines if identity is confirmed (>77% confidence)

4. **Attendance Marking**:
   - System checks if student's attendance was already marked for the day
   - If not already marked, adds entry to attendance.csv
   - Displays confirmation message on screen
   - Prevents duplicate attendance entries

5. **Attendance Viewing**:
   - Reads attendance.csv file
   - Displays records in a formatted, readable manner
   - Allows sorting and filtering of records

## Data Flow Diagram
```
┌────────────┐     ┌───────────────┐     ┌────────────────┐
│  Camera    │────▶│  Face         │────▶│  Student       │
│  Input     │     │  Detection    │     │  Identification │
└────────────┘     └───────────────┘     └────────────────┘
                                                 │
                                                 ▼
┌────────────┐     ┌───────────────┐     ┌────────────────┐
│ Attendance │◀────│  Attendance   │◀────│  Database      │
│ Records    │     │  Marking      │     │  Lookup        │
└────────────┘     └───────────────┘     └────────────────┘
```

## Integration Points
- **Database to Face Recognition**: The system loads student information from the database during recognition
- **Recognition to Attendance**: On successful recognition, attendance is marked in the CSV file
- **UI to System Functions**: User interface buttons trigger corresponding functions
- **Attendance CSV to UI Display**: Attendance records are read from CSV and displayed in the View Attendance window

## Security and Error Handling
- **Data Validation**: Input validation for database operations
- **Error Recovery**: Graceful handling of file operations and database errors
- **Resource Management**: Proper release of camera and other resources

## Future Enhancement Possibilities
- Cloud database integration
- Mobile application interface
- Automated email/SMS notifications
- Statistical analysis of attendance data
- Multi-camera support 